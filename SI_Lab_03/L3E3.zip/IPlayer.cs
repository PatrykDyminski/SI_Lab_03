﻿namespace SI_Lab_03
{
    interface IPlayer
    {
        public int Move(int[,] board);
    }
}
