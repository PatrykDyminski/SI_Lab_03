﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SI_Lab_03.ScoringFunctions
{
    class OtherScore : IScoreBoard
    {
        public int Score(int[,] board, int player)
        {
            throw new NotImplementedException();
        }

        //int ScoreRow(int[] row)
        //{
        //    int score = 0;



        //    row.Intersect();
        //}
    }
}
