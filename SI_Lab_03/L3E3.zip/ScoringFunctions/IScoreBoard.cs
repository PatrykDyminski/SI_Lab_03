﻿namespace SI_Lab_03.ScoringFunctions
{
    interface IScoreBoard
    {
        int Score(int[,] board, int player);
    }
}
